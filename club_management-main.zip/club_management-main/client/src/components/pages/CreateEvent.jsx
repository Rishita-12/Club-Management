import React from 'react'

function CreateEvent() {
  return (
    <div>
      
    </div>
  )
}

export default CreateEvent
