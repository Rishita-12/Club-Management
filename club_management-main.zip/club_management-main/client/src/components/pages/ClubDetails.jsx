//for every solo club page  
import React from 'react'

function ClubDetails() {
  return (
    <div>
      ClubDetails
    </div>
  )
}

export default ClubDetails
